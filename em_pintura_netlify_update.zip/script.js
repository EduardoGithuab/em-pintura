const senhaCorreta='@123';

function entrar(){
 if(document.getElementById('senha').value===senhaCorreta){
  login.style.display='none';
  app.style.display='block';
  atualizarPainel();
 } else alert('Senha incorreta');
}

function calcular(){
 let interna=Number(document.getElementById('interna').value)||0;
 let externa=Number(document.getElementById('externa').value)||0;
 let custo=Number(document.getElementById('custo').value)||0;

 let total=(interna*25)+(externa*30);

 if(document.getElementById('pagamento').value==='cartao') total*=1.05;

 let lucro=total-custo;

 document.getElementById('resultado').innerHTML=
 `Total: R$ ${total.toFixed(2)}<br>Lucro: R$ ${lucro.toFixed(2)}`;

 salvarFinanceiro(total,custo);
 atualizarPainel();
}

function salvarFinanceiro(valor,custo){
 let dados=JSON.parse(localStorage.getItem('financeiro'))||[];
 dados.push({valor:valor,custo:custo,data:new Date()});
 localStorage.setItem('financeiro',JSON.stringify(dados));
}

function atualizarPainel(){
 let dados=JSON.parse(localStorage.getItem('financeiro'))||[];
 let mes=new Date().getMonth();

 let fat=0,lucro=0,qtd=0;

 dados.forEach(d=>{
  let data=new Date(d.data);
  if(data.getMonth()===mes){
    fat+=d.valor;
    lucro+=(d.valor-d.custo);
    qtd++;
  }
 });

 let margem=fat>0?(lucro/fat)*100:0;

 document.getElementById('fat').innerText=fat.toFixed(2);
 document.getElementById('lucroTotal').innerText=lucro.toFixed(2);
 document.getElementById('qtd').innerText=qtd;
 document.getElementById('margemMedia').innerText=margem.toFixed(1);
}

function limparMes(){
 if(confirm('Limpar dados?')){
  localStorage.removeItem('financeiro');
  atualizarPainel();
 }
}
